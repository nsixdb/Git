// Test if your .env file is working ;-)

require('dotenv').config();
console.log(process.env);
